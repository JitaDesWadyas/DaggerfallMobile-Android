# Build APK with GitHub Actions

1. Create an empty GitHub repository (suggested `DaggerfallMobile-Android`) under your account.
2. Upload the contents of this archive to repository root on `main` (including `.github/workflows/android-apk.yml`).
3. Go to the repository **Actions** > **Build Android APK** > **Run workflow** (or simply push the files).
4. On a successful run, open the run and download the **DaggerfallMobile-debug-apk** artifact; unzip it to get `app-debug.apk`.
5. Install the APK on your Android phone. Debug APKs are signed automatically by Android Gradle Plugin and are suitable for manual testing, not Play Store distribution.

Warning: This is the v4 source and the login issue is **not confirmed fixed**. This workflow automates builds only; it does not resolve the underlying input/login bug.
The original DaggerfallJS repository and website are not modified.
