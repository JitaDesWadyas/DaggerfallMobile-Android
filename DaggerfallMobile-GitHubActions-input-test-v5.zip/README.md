# Daggerfall Mobile 1.1

An independent Android client built with Kotlin and Android System WebView. No game code is included or modified. The app loads https://daggerfalljs.dev/.

## How to use
Install the APK, open the website, and sign in with the virtual controller initially turned off. Open ☰ → Controller ON to play. If required, also enable the controller in the game's settings. For LT/RT analog triggers, drag vertically inside the button (top = 100%, middle = 50%, bottom = 0%).

The ☰ menu provides Android keyboard, custom keyboard, ESC/TAB/ENTER, controller layout editor, settings, three profiles, browser navigation, diagnostics, and exit controls. In the editor, tap or drag a control to select or move it. Adjust its size, opacity, and visibility from the menu. Hidden controls remain selectable in edit mode.

## Login workaround (version 1.1)
Some devices have a focus issue: tapping the username field may exit the sign-in screen, or pressing Tab after entering a password may navigate back. This build includes a page-side input event workaround and an **Alternative login** dialog with native Android text fields.

1. Open **Sign in** or **Create account** on the website.
2. Open the app's ☰ menu and choose **Alternative login**.
3. Enter your details using native Android inputs, then choose **Fill fields** or **Fill and sign in**.

The native dialog transfers values to the website's existing input fields and attempts to activate its own submit button. It does not use a separate login endpoint or store the password. The underlying website's sign-in or registration behavior is not modified. Whether it resolves the issue on every device remains unverified.

A QWERTY custom keyboard with numbers, SHIFT, symbols, space, backspace, ENTER, TAB and ESC is also available. Portrait, landscape, and automatic rotation have separate persistent controller layouts.

## Build
Requires JDK 17, Android SDK 35 and build-tools 35.0.0. Set `ANDROID_HOME` or `sdk.dir` in `local.properties`.

```bash
./gradlew :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Features
- Hardware-accelerated WebView with JavaScript, DOM storage, persistent cookies, and the original user agent.
- Android file picker for uploads, DownloadManager for HTTPS downloads, document picker for blob/data downloads (36 MB maximum).
- Portrait, landscape and automatic orientation; immersive fullscreen; keyboard resizing and lifecycle handling; back button opens the menu.
- Standard gamepad mapping with 17 buttons, four axes, multitouch, analog sticks/triggers and automatic reset on focus loss.
- AndroidX WebKit document-start shim in the site's page context. Only `daggerfalljs.dev` origins and relevant frames are targeted.
- Three controller layout profiles per orientation, global sensitivity/deadzone and on-screen editor.
- Only INTERNET permission; no bundled Chromium engine or native game libraries.

## Tests and known limitations
The original project reported a successful debug build and signing, plus Node tests for the gamepad and login workaround. These outcomes have **not been reverified for this English-translation ZIP**. It has not been tested on a Nothing Phone 3a or an Android emulator. Actual login behavior, soft keyboard, WebGL2, and in-game controller functionality need on-device verification. WebGL2 depends on Android WebView and the GPU.

In Diagnostics, `gamepad.installed` should be true and `reads` should increase as the game polls the controller API. This does not prove that the game enabled the controller. If document-start JavaScript is unsupported, the app warns and falls back to later injection; update Android System WebView if necessary.

### Login field event fix (client-side only)

The document-start `login-fix.js` now allows native touch/click/keyboard events to reach the site's actual input elements. Previously, capturing listeners on `window` called `stopImmediatePropagation`, which prevented the event from reaching the input and caused broken account sign-in. Instead, this revision wraps *later-registered* `window` and `document` listeners for game-wide shortcuts and ignores those listeners only when the event targets an editable field. It does not change the original game's source code, server, or Git repository. The alternative Android-native login dialog remains available from the in-app menu.

Run `node tests/login-fix.test.cjs` and `node tests/gamepad-shim.test.cjs` before building. These are unit-level tests, not proof of a successful login on a real Android device.

## Native sign-in workaround (v3)
Open the site's Account window (do not tap its username/password fields), tap the app's ☰ menu, and choose **Native sign in**. The app tries to advance the website's own sign-in stage by clicking its existing Sign in button in the DOM. Credentials are typed into native Android text boxes and applied to the original website fields before invoking its own submit button. This does not modify the website's source or server. Gamepad touch controls are switched off while signing in. Registration still uses the existing website flow.

This is an unverified device workaround; automated JS tests alone cannot prove real account login.

## v1.3 account input isolation

Account input classes and inline pointer/focus/key handlers are stripped inside
our Android WebView only, including newly rendered account screens. The site's
`oninput` callback is preserved; removing it would break authentication.
Native sign-in calls that callback directly after updating each field and does
not dispatch synthetic DOM `input` or `change` events. This is not a change to
DaggerfallJS source, nor does it guarantee that the remote site has no other
navigation or global event logic. Device login/registration are not yet verified.
