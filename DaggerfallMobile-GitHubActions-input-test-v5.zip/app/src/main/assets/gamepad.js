(()=>{
 if(window.__dfPad)return;
 const original=navigator.getGamepads?.bind(navigator);
 let reads=0,connected=false;
 const pad={id:'Xbox 360 Controller (Daggerfall Mobile)',index:0,connected:true,mapping:'standard',timestamp:performance.now(),axes:[0,0,0,0],buttons:Array.from({length:17},()=>({pressed:false,touched:false,value:0})),vibrationActuator:null};
 const desc=Object.getOwnPropertyDescriptor(Navigator.prototype,'getGamepads');
 const getter=()=>{reads++;let list=[];try{list=original?Array.from(original()):[]}catch(e){};list[0]=pad;while(list.length<4)list.push(null);return list;};
 let installed=false,error='';
 try{Object.defineProperty(navigator,'getGamepads',{value:getter,configurable:true});installed=navigator.getGamepads===getter;}catch(e){error=String(e);if(!desc||desc.configurable){try{Object.defineProperty(Navigator.prototype,'getGamepads',{value:getter,configurable:true});installed=navigator.getGamepads===getter;}catch(e2){error=String(e2)}}}
 window.__dfPad={update(s){pad.axes.splice(0,4,...s.axes);s.buttons.forEach((v,i)=>Object.assign(pad.buttons[i],{value:v,pressed:v>0.5,touched:v>0}));pad.timestamp=performance.now();if(!connected&&(s.buttons.some(v=>v>0)||s.axes.some(v=>v!==0))){connected=true;let event;try{event=new GamepadEvent('gamepadconnected',{gamepad:pad})}catch(e){event=new Event('gamepadconnected');Object.defineProperty(event,'gamepad',{value:pad})};window.dispatchEvent(event);}},status(){return {installed,error,reads,axes:pad.axes,buttons:pad.buttons.map(b=>b.value),frame:location.href,webgl2:!!document.createElement('canvas').getContext('webgl2')}},reset(){this.update({axes:[0,0,0,0],buttons:Array(17).fill(0)})}};
 // Each allowed frame receives its own document-start shim and receives state through postMessage.
 addEventListener('message',e=>{if(e.origin==='https://daggerfalljs.dev'&&e.data?.dfMobileState)window.__dfPad.update(e.data.dfMobileState)});
 window.__dfUpdate=s=>{window.__dfPad.update(s);for(const f of document.querySelectorAll('iframe')){try{f.contentWindow.postMessage({dfMobileState:s},'https://daggerfalljs.dev')}catch(e){}}};
})();
