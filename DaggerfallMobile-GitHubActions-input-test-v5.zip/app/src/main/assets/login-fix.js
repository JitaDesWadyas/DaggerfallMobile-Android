(()=>{
 if(window.__dfLoginFix)return;
 const editable=t=>t instanceof Element&&!!t.closest('input:not([type=button]):not([type=submit]):not([type=checkbox]):not([type=radio]),textarea,[contenteditable=true]');
 const field=t=>editable(t)?t.closest('input,textarea,[contenteditable=true]'):null;
 const visible=e=>e.isConnected&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
 window.__dfFocused=null;
 // Install at document start. Do NOT stop events in capture phase: that prevents
 // the input itself from receiving taps and stops the site's own handlers.
 // Instead shield editable-field events from global game/menu shortcuts only.
 const globalEvents=new Set(['pointerdown','pointerup','mousedown','mouseup','click','dblclick','touchstart','touchend','keydown','keyup','keypress']);
 const add=EventTarget.prototype.addEventListener;
 const remove=EventTarget.prototype.removeEventListener;
 const wrapped=new WeakMap();
 const captureOf=o=>typeof o==='boolean'?o:!!o?.capture;
 const mapFor=listener=>{let m=wrapped.get(listener);if(!m){m=new Map();wrapped.set(listener,m)}return m};
 EventTarget.prototype.addEventListener=function(type,listener,options){
   if((this===window||this===document)&&globalEvents.has(type)&&listener){
     const id=type+':'+captureOf(options), m=mapFor(listener);
     if(!m.has(id))m.set(id,function(event){
       if(editable(event.target))return;
       if(typeof listener==='function')return listener.call(this,event);
       return listener.handleEvent?.(event);
     });
     return add.call(this,type,m.get(id),options);
   }
   return add.call(this,type,listener,options);
 };
 EventTarget.prototype.removeEventListener=function(type,listener,options){
   const mapped=listener&&wrapped.get(listener)?.get(type+':'+captureOf(options));
   return remove.call(this,type,mapped||listener,options);
 };
 add.call(window,'pointerdown',e=>{if(editable(e.target)){window.__dfFocused=field(e.target);window.dfInputFocus?.postMessage('focus')}},false);
 add.call(window,'focusin',e=>{if(editable(e.target))window.__dfFocused=field(e.target)},false);
 // Call the site's own field handler directly, without dispatching an event.
 // Synthetic input/change events were triggering the site's global menu handlers.
 const setter=(e,value)=>{
   const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
   const original=Object.getOwnPropertyDescriptor(proto,'value');
   original.set.call(e,value);
   if(typeof e.oninput==='function')e.oninput.call(e,new Event('input'));
 };
 const accountInputs=()=>Array.from(document.querySelectorAll('.acct input,.acct textarea,.px-acctwin input,.px-acctwin textarea')).filter(e=>visible(e)&&!e.disabled&&!e.readOnly&&!['submit','button','checkbox','radio','file','hidden','range','color'].includes(e.type));
 // Strip only input classes and intrusive inline event handlers; the game's oninput
 // callback remains attached, since its account flow owns authentication state.
 const originalAttrs=new WeakMap();
 const sanitize=()=>{
   let n=0;
   for(const e of accountInputs()){
     if(e.dataset?.dfCleaned==='1')continue;
     originalAttrs.set(e,{className:e.getAttribute('class'),id:e.getAttribute('id'),name:e.getAttribute('name')});
     e.removeAttribute?.('class');
     for(const name of ['onclick','onpointerdown','onpointerup','ontouchstart','ontouchend','onmousedown','onmouseup','onfocus','onblur','onkeydown','onkeyup'])e.removeAttribute?.(name);
     if(e.dataset)e.dataset.dfCleaned='1';
     n++;
   }
   return n;
 };
 // Account cards are dynamically rebuilt, so strip attributes on every rebuild.
 // Observe only structural changes to avoid loops from value/class updates.
 if(typeof MutationObserver==='function'){
   const observe=()=>{
     if(!document.body)return;
     const observer=new MutationObserver(records=>{
       if(records.some(r=>r.addedNodes?.length))sanitize();
     });
     observer.observe(document.body,{childList:true,subtree:true});
     sanitize();
   };
   if(document.body)observe();else document.addEventListener('DOMContentLoaded',observe,{once:true});
 }
 window.__dfLoginFix={
 // Click the website's own navigation button, without ever touching a text input.
 open(stage='login'){
   const all=Array.from(document.querySelectorAll('button,[role="button"],input[type="button"]')).filter(visible);
   const text=b=>(b.textContent||b.value||b.getAttribute('aria-label')||'').trim();
   const wanted=stage==='register'?/^(create account|register|sign up)$/i:/^(sign in|log in|login)$/i;
   const account=all.filter(b=>b.closest('.acct,.px-acctwin,[role="dialog"]'));
   const b=account.find(b=>wanted.test(text(b)))||all.find(b=>wanted.test(text(b)));
   if(!b||b.disabled)return false;
   b.click();return true;
 },
 sanitize,
 fields(){const all=accountInputs();window.__dfLoginTargets=all;return all.map((e,i)=>({index:i,key:e.acctKey||'',type:e.type,label:e.labels?.[0]?.textContent?.trim()||e.getAttribute('aria-label')||e.placeholder||e.name||e.type,value:e.value}))},
 // A fresh lookup for every field is necessary: the website recreates the card
 // after flow.set(). Never target a stale element.
 fill(values,submit){
   const descriptors=this.fields();
   if(values.length!==descriptors.length||!descriptors.length)return false;
   for(let i=0;i<values.length;i++){
     const key=descriptors[i].key;
     const current=accountInputs();
     const e=(key?current.find(x=>x.acctKey===key):null)||current[i];
     if(!e)return false;
     setter(e,String(values[i]));
   }
   if(submit){
     const scope=document.querySelector('.px-acctwin .acct,.acct,.px-acctwin');
     const candidates=scope?Array.from(scope.querySelectorAll('button,input[type=submit]')).filter(visible):[];
     const b=candidates.find(e=>e.acctKey==='act:submit')||candidates.find(e=>e.type==='submit')||candidates.find(e=>/^(sign in|log in|login)$/i.test((e.textContent||e.value||'').trim()));
     if(!b||b.disabled)return false;
     b.click();
   }
   return true;
 },
 focus(){let e=window.__dfFocused;if(!e||!visible(e))e=this.fields().length?window.__dfLoginTargets[0]:null;if(!e)return false;window.__dfFocused=e;e.focus({preventScroll:true});return document.activeElement===e},
 type(text){const e=window.__dfFocused;if(!e||!visible(e))return false;if(e.isContentEditable){e.focus();document.execCommand('insertText',false,text);return true}const start=e.selectionStart??e.value.length,end=e.selectionEnd??start;setter(e,e.value.slice(0,start)+text+e.value.slice(end));try{e.setSelectionRange(start+text.length,start+text.length)}catch(_){};return true},
 backspace(){const e=window.__dfFocused;if(!e||!visible(e))return false;let start=e.selectionStart??e.value.length,end=e.selectionEnd??start;if(start===end)start=Math.max(0,start-1);setter(e,e.value.slice(0,start)+e.value.slice(end));try{e.setSelectionRange(start,start)}catch(_){};return true}
 };
})();
