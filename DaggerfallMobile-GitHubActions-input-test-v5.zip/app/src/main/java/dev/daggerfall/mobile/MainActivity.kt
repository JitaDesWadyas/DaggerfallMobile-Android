package dev.daggerfall.mobile

import android.app.*
import android.os.*
import android.content.*
import android.net.Uri
import android.graphics.*
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.*
import kotlin.math.*

class MainActivity: Activity() {
 lateinit var web: WebView
 lateinit var root: FrameLayout
 lateinit var pad: PadView
 private var chooser: ValueCallback<Array<Uri>>?=null
 private var custom: View?=null
 private var customCallback: WebChromeClient.CustomViewCallback?=null
 private var docStart=false
 private var downloadBytes:ByteArray?=null
 private val prefs by lazy {getSharedPreferences("controller",MODE_PRIVATE)}
 override fun onCreate(state: Bundle?) {
  super.onCreate(state)
  requestedOrientation=prefs.getInt("orientation",android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR)
  layoutOrientation=resources.configuration.orientation
  window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
  root=FrameLayout(this);setContentView(root)
  web=WebView(this);root.addView(web,FrameLayout.LayoutParams(-1,-1))
  web.isFocusableInTouchMode=true
  web.settings.apply {javaScriptEnabled=true;domStorageEnabled=true;mediaPlaybackRequiresUserGesture=false;allowFileAccess=false;allowContentAccess=true;setSupportMultipleWindows(false)}
  CookieManager.getInstance().apply {setAcceptCookie(true);setAcceptThirdPartyCookies(web,true)}
  if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) WebViewCompat.addWebMessageListener(web,"dfDownload",setOf("https://daggerfalljs.dev")){_,message,origin,main,_ ->
   if(origin.host=="daggerfalljs.dev"&&main)try{val o=JSONObject(message.data?:"{}");val data=o.getString("data");if(data.length>48*1024*1024)throw Exception("File too large (max 36 MB)");downloadBytes=android.util.Base64.decode(data,android.util.Base64.DEFAULT);startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(o.optString("mime","application/octet-stream")).putExtra(Intent.EXTRA_TITLE,o.optString("name","Daggerfall-save.bin")),8)}catch(e:Exception){downloadBytes=null;toast("Export: ${e.message}")}
  }
  if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) WebViewCompat.addWebMessageListener(web,"dfInputFocus",setOf("https://daggerfalljs.dev")){_,_,origin,main,_ ->if(origin.host=="daggerfalljs.dev"&&main)web.postDelayed({web.requestFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(web,InputMethodManager.SHOW_IMPLICIT)},80)}
  val shim=assets.open("gamepad.js").bufferedReader().readText()+"\n"+assets.open("login-fix.js").bufferedReader().readText()
  if(WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {WebViewCompat.addDocumentStartJavaScript(web,shim,setOf("https://daggerfalljs.dev"));docStart=true}
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean {if(r.url.scheme=="https"||r.url.scheme=="http")return false;try{startActivity(Intent(Intent.ACTION_VIEW,r.url))}catch(e:Exception){toast("Nessuna app per questo link")};return true}
   override fun onPageFinished(v:WebView,url:String){if(!docStart&&Uri.parse(url).host=="daggerfalljs.dev"){v.evaluateJavascript(shim,null);toast("WebView obsoleta: aggiorna Android System WebView. Shim tardivo.")};pad.reset();CookieManager.getInstance().flush()}
   override fun onRenderProcessGone(v:WebView,d:RenderProcessGoneDetail):Boolean {root.removeView(v);v.destroy();AlertDialog.Builder(this@MainActivity).setMessage("WebView terminata. Riaprire l'app?").setPositiveButton("Riapri"){_,_->recreate()}.setNegativeButton("Esci"){_,_->finish()}.show();return true}
  }
  web.webChromeClient=object:WebChromeClient(){
   override fun onShowFileChooser(v:WebView,c:ValueCallback<Array<Uri>>,p:FileChooserParams):Boolean {chooser?.onReceiveValue(null);chooser=c;try{startActivityForResult(p.createIntent(),7)}catch(e:Exception){chooser?.onReceiveValue(null);chooser=null;return false};return true}
   override fun onShowCustomView(v:View,c:CustomViewCallback){if(custom!=null){c.onCustomViewHidden();return};custom=v;customCallback=c;root.addView(v,FrameLayout.LayoutParams(-1,-1));pad.bringToFront();menuButton.bringToFront();immersive()}
   override fun onHideCustomView(){custom?.let{root.removeView(it)};custom=null;customCallback?.onCustomViewHidden();customCallback=null}
  }
  web.setDownloadListener {url,ua,disposition,mime,_->
   if(url.startsWith("blob:")||url.startsWith("data:")){val u=JSONObject.quote(url);val n=JSONObject.quote(URLUtil.guessFileName(url,disposition,mime));web.evaluateJavascript("(async()=>{try{const b=await (await fetch($u)).blob();const r=new FileReader();r.onload=()=>window.dfDownload?.postMessage(JSON.stringify({name:$n,mime:b.type||'application/octet-stream',data:r.result.split(',')[1]}));r.readAsDataURL(b)}catch(e){alert('Download: '+e.message)}})()",null);return@setDownloadListener}
   if(!url.startsWith("https://")){toast("Protocollo download non supportato");return@setDownloadListener}
   try{val name=URLUtil.guessFileName(url,disposition,mime);val req=android.app.DownloadManager.Request(Uri.parse(url)).setTitle(name).setMimeType(mime).addRequestHeader("User-Agent",ua).addRequestHeader("Cookie",CookieManager.getInstance().getCookie(url)?:"").setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,name);(getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(req);toast("Download avviato")}catch(e:Exception){toast("Download: ${e.message}")}
  }
  pad=PadView();root.addView(pad,FrameLayout.LayoutParams(-1,-1))
  if(Build.VERSION.SDK_INT>=30)root.setOnApplyWindowInsetsListener {_,insets ->
   val ime=insets.getInsets(WindowInsets.Type.ime());root.setPadding(0,0,0,ime.bottom);pad.visibility=if(insets.isVisible(WindowInsets.Type.ime()))View.GONE else View.VISIBLE;insets
  }
  menuButton=Button(this).apply {text="☰";alpha=.65f;setOnClickListener{settings()}}
  root.addView(menuButton,FrameLayout.LayoutParams(58.dp,48.dp,Gravity.TOP or Gravity.RIGHT))
  if(state==null||web.restoreState(state)==null)web.loadUrl("https://daggerfalljs.dev/")
  immersive()
  if(state==null)toast("Sign in to the website, then open ☰ → Controller ON to play.")
 }
 lateinit var menuButton:Button
 val Int.dp:Int get()=(this*resources.displayMetrics.density).toInt()
 fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
 fun immersive(){window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE}
 private var menuDialog:Dialog?=null
 private var keyboardPanel:LinearLayout?=null
 private var customShift=false
 private var customSymbols=false
 private var layoutOrientation=0
 private val dark=Color.rgb(15,21,31)
 private val accent=Color.rgb(208,161,84)
 fun surface(color:Int=dark)=android.graphics.drawable.GradientDrawable().apply{setColor(color);cornerRadius=18.dp.toFloat();setStroke(1.dp,Color.rgb(53,66,81))}
 fun label(text:String,size:Float=16f)=TextView(this).apply{this.text=text;textSize=size;setTextColor(Color.WHITE);setPadding(12.dp,10.dp,12.dp,8.dp)}
 fun action(text:String,run:()->Unit)=Button(this).apply{this.text=text;textSize=13f;isAllCaps=false;setTextColor(Color.WHITE);background=surface(Color.rgb(31,43,59));setPadding(8.dp,4.dp,8.dp,4.dp);setOnClickListener{run()}}
 fun panelDialog(title:String):Pair<Dialog,LinearLayout>{val d=Dialog(this);val box=LinearLayout(this).apply{orientation=1;background=surface();setPadding(12.dp,8.dp,12.dp,12.dp)};box.addView(label(title,22f));val scroll=ScrollView(this);val body=LinearLayout(this).apply{orientation=1};scroll.addView(body);box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));d.setContentView(box);d.window?.setBackgroundDrawableResource(android.R.color.transparent);d.window?.setLayout(min(resources.displayMetrics.widthPixels-24.dp,560.dp),min(resources.displayMetrics.heightPixels-36.dp,650.dp));return Pair(d,body)}
 fun row(box:LinearLayout,vararg entries:Pair<String,()->Unit>){val r=LinearLayout(this);entries.forEach{(name,fn)->r.addView(action(name,fn),LinearLayout.LayoutParams(0,48.dp,1f).apply{setMargins(3.dp,3.dp,3.dp,3.dp)})};box.addView(r)}
 fun settings(){pad.reset();hideCustomKeyboard();menuDialog?.dismiss();val(d,b)=panelDialog("DAGGERFALL  /  MOBILE");menuDialog=d
  b.addView(label("LOGIN AND KEYS",12f))
  row(b,"Native sign in" to {d.dismiss();nativeLogin()},"Android keyboard" to {d.dismiss();keyboard()})
  row(b,"Custom keyboard" to {d.dismiss();showCustomKeyboard()},"ESC" to {d.dismiss();key(KeyEvent.KEYCODE_ESCAPE)})
  row(b,"TAB" to {d.dismiss();key(KeyEvent.KEYCODE_TAB)},"ENTER" to {d.dismiss();key(KeyEvent.KEYCODE_ENTER)})
  b.addView(label("DISPLAY AND CONTROLLER",12f))
  row(b,"Portrait" to {d.dismiss();orientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)},"Landscape" to {d.dismiss();orientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE)},"Auto" to {d.dismiss();orientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR)})
  row(b,"Controller ${if(pad.controlsEnabled) "ON" else "OFF"}" to {d.dismiss();pad.controlsEnabled=!pad.controlsEnabled;pad.invalidate()},"Editor ${if(pad.edit) "ON" else "OFF"}" to {d.dismiss();pad.edit=!pad.edit;pad.invalidate();if(pad.edit)toast("Drag controls to move them. Select a control to change its settings.")})
  row(b,"Selected control" to {d.dismiss();elementSettings()},"Sensitivity" to {d.dismiss();tuning()})
  row(b,"Save profile" to {d.dismiss();profile(true)},"Load profile" to {d.dismiss();profile(false)},"Reset layout" to {d.dismiss();pad.defaults();pad.save()})
  b.addView(label("BROWSER",12f))
  row(b,"Back" to {d.dismiss();if(web.canGoBack())web.goBack()},"Forward" to {d.dismiss();if(web.canGoForward())web.goForward()},"Reload" to {d.dismiss();web.reload()})
  row(b,"Diagnostics" to {d.dismiss();diagnostics()},"Exit fullscreen" to {d.dismiss();web.webChromeClient?.onHideCustomView();window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_VISIBLE})
  row(b,"BACK TO GAME" to {d.dismiss();immersive()},"Exit app" to {d.dismiss();finish()})
  d.show();d.window?.setLayout(min(resources.displayMetrics.widthPixels-24.dp,560.dp),min(resources.displayMetrics.heightPixels-36.dp,650.dp))
 }
 fun diagnostics(){web.evaluateJavascript("JSON.stringify({gamepad:window.__dfPad?.status(),loginFields:window.__dfLoginFix?.fields().map(f=>({type:f.type,label:f.label}))})"){s->val(d,b)=panelDialog("Diagnostics");b.addView(label("Document-start: $docStart\n$s\nreads increases when the game polls the controller.",13f));row(b,"Close" to {d.dismiss()});d.show();d.window?.setLayout(min(resources.displayMetrics.widthPixels-24.dp,560.dp),min(resources.displayMetrics.heightPixels-36.dp,600.dp))}}
 fun orientation(mode:Int){prefs.edit().putInt("orientation",mode).apply();requestedOrientation=mode}
 fun keyboard(){hideCustomKeyboard();pad.reset();web.evaluateJavascript("window.__dfLoginFix?.focus()") { web.post {window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_LAYOUT_STABLE;web.requestFocus();if(Build.VERSION.SDK_INT>=30)window.insetsController?.show(WindowInsets.Type.ime());(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(web,InputMethodManager.SHOW_IMPLICIT)} }}
 fun nativeLogin(){pad.reset();pad.controlsEnabled=false;pad.invalidate();
  // Open the real website sign-in stage by clicking its button via DOM; no touch/focus on buggy fields.
  web.evaluateJavascript("window.__dfLoginFix?.open('login');window.__dfLoginFix?.sanitize()",null)
  web.postDelayed({nativeLoginFields(0)},250)
 }
 fun nativeLoginFields(attempt:Int){web.evaluateJavascript("JSON.stringify(window.__dfLoginFix?.fields()||[])"){raw->try{
  val decoded=JSONTokener(raw).nextValue() as? String?:"[]";val fields=JSONArray(decoded);if(fields.length()==0){if(attempt<5){web.postDelayed({nativeLoginFields(attempt+1)},300)}else toast("Open the website account menu, then tap ☰ → Native sign in. No need to touch username or password.");return@evaluateJavascript}
  val(d,b)=panelDialog("Website login");b.addView(label("Enter your details here. They will be entered into the website fields and will not be saved.",13f));val inputs=mutableListOf<EditText>()
  for(i in 0 until fields.length()){val f=fields.getJSONObject(i);b.addView(label(f.optString("label","Field ${i+1}"),13f));val input=EditText(this).apply{setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);setSingleLine(true);inputType=if(f.optString("type")=="password")android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;setText(f.optString("value"));background=surface(Color.rgb(26,36,51));setPadding(12.dp,8.dp,12.dp,8.dp)};inputs.add(input);b.addView(input,LinearLayout.LayoutParams(-1,52.dp).apply{setMargins(4.dp,0,4.dp,8.dp)})}
  val apply:(Boolean)->Unit={submit->val values=JSONArray();inputs.forEach{values.put(it.text.toString())};d.dismiss();web.evaluateJavascript("window.__dfLoginFix?.sanitize();window.__dfLoginFix?.fill($values,$submit)"){result->if(result!="true")toast("Fields filled. Press Sign in on the website.")};inputs.forEach{it.text.clear()}}
  row(b,"Fill fields" to {apply(false)},"Fill and sign in" to {apply(true)})
  row(b,"Cancel" to {d.dismiss();inputs.forEach{it.text.clear()}})
  d.show();d.window?.setLayout(min(resources.displayMetrics.widthPixels-24.dp,520.dp),min(resources.displayMetrics.heightPixels-48.dp,600.dp));d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);inputs.firstOrNull()?.requestFocus();inputs.firstOrNull()?.post{(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(inputs[0],InputMethodManager.SHOW_IMPLICIT)}
 }catch(e:Exception){toast("Native sign in: ${e.message}")}}}
 fun hideCustomKeyboard(){keyboardPanel?.let{root.removeView(it)};keyboardPanel=null;val lp=web.layoutParams as FrameLayout.LayoutParams;lp.bottomMargin=0;web.layoutParams=lp;val pp=pad.layoutParams as FrameLayout.LayoutParams;pp.bottomMargin=0;pad.layoutParams=pp}
 fun textKey(text:String){web.evaluateJavascript("window.__dfLoginFix?.type(${JSONObject.quote(text)})"){used->if(used!="true"){web.requestFocus();KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(text.toCharArray())?.forEach{web.dispatchKeyEvent(it)}}}}
 fun showCustomKeyboard(){hideCustomKeyboard();pad.reset();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(web.windowToken,0);web.evaluateJavascript("window.__dfLoginFix?.focus()",null);renderKeyboard()}
 fun renderKeyboard(){keyboardPanel?.let{root.removeView(it)};val panel=LinearLayout(this).apply{orientation=1;background=surface();setPadding(3.dp,3.dp,3.dp,3.dp)};keyboardPanel=panel
  fun keys(chars:String){val row=LinearLayout(this);for(c in chars){val text=if(customShift)c.uppercaseChar().toString() else c.toString();row.addView(action(text){textKey(text)}.apply{isFocusable=false;textSize=14f},LinearLayout.LayoutParams(0,40.dp,1f).apply{setMargins(1.dp,1.dp,1.dp,1.dp)})};panel.addView(row)}
  keys("1234567890");if(customSymbols){keys("!@#\$%&*()_");keys("+-=/:;?,.");keys("[]{}<>\\|~")}else{keys("qwertyuiop");keys("asdfghjkl");keys("zxcvbnm@.-")}
  row(panel,"SHIFT" to {customShift=!customShift;renderKeyboard()},"SYM" to {customSymbols=!customSymbols;renderKeyboard()},"SPACE" to {textKey(" ")},"⌫" to {web.evaluateJavascript("window.__dfLoginFix?.backspace()"){used->if(used!="true")key(KeyEvent.KEYCODE_DEL)}},"ENTER" to {key(KeyEvent.KEYCODE_ENTER)})
  row(panel,"ESC" to {key(KeyEvent.KEYCODE_ESCAPE)},"TAB" to {key(KeyEvent.KEYCODE_TAB)},"Android" to {keyboard()},"Close" to {hideCustomKeyboard()})
  val h=276.dp;root.addView(panel,FrameLayout.LayoutParams(-1,h,Gravity.BOTTOM));menuButton.bringToFront();val lp=web.layoutParams as FrameLayout.LayoutParams;lp.bottomMargin=h;web.layoutParams=lp;val pp=pad.layoutParams as FrameLayout.LayoutParams;pp.bottomMargin=h;pad.layoutParams=pp
 }

 fun key(code:Int){web.requestFocus();web.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,code));web.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP,code))}
 fun slider(parent:LinearLayout,label:String,max:Int,value:Int,change:(Int)->Unit){val t=TextView(this);t.text="$label: $value";parent.addView(t);val s=SeekBar(this);s.max=max;s.progress=value;parent.addView(s);s.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(b:SeekBar,v:Int,user:Boolean){t.text="$label: $v";change(v)};override fun onStartTrackingTouch(b:SeekBar){};override fun onStopTrackingTouch(b:SeekBar){}})}
 fun elementSettings(){val e=pad.selected?:run{toast("Enable the editor and tap a control");return};val box=LinearLayout(this);box.orientation=1;slider(box,"Size",180,(e.r*1000).toInt()){e.r=max(.015f,it/1000f);pad.invalidate()};slider(box,"Opacity",100,(e.alpha*100).toInt()){e.alpha=it/100f;pad.invalidate()};val visible=CheckBox(this);visible.text="Visible";visible.isChecked=!e.hidden;visible.setOnCheckedChangeListener{_,v->e.hidden=!v;pad.invalidate()};box.addView(visible);AlertDialog.Builder(this).setTitle(e.name).setView(box).setPositiveButton("Save"){_,_->pad.save()}.show()}
 fun tuning(){val b=LinearLayout(this);b.orientation=1;slider(b,"Sensitivity %",200,(pad.sensitivity*100).toInt()){pad.sensitivity=max(.1f,it/100f)};slider(b,"Deadzone %",50,(pad.deadzone*100).toInt()){pad.deadzone=it/100f};AlertDialog.Builder(this).setView(b).setPositiveButton("Save"){_,_->pad.save()}.show()}
 fun profile(save:Boolean){val names=arrayOf("Profile 1","Profile 2","Profile 3");AlertDialog.Builder(this).setTitle(if(save)"Save profile" else "Load profile").setItems(names){_,i->if(save)pad.save("profile$i-$layoutOrientation")else pad.load("profile$i-$layoutOrientation")}.show()}
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==8){val bytes=downloadBytes;downloadBytes=null;if(c==RESULT_OK&&d?.data!=null&&bytes!=null)try{(contentResolver.openOutputStream(d.data!!)?:throw Exception("Destination is not writable")).use{it.write(bytes)};toast("File saved")}catch(e:Exception){toast("Savetaggio: ${e.message}")};return};if(r==7){chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));chooser=null;web.requestFocus()}}
 override fun onConfigurationChanged(config:android.content.res.Configuration){if(::pad.isInitialized)pad.save("layout$layoutOrientation");super.onConfigurationChanged(config);layoutOrientation=config.orientation;if(::pad.isInitialized){pad.reset();pad.defaults();pad.load()};if(keyboardPanel!=null)renderKeyboard()}
 override fun onSaveInstanceState(s:Bundle){web.saveState(s);super.onSaveInstanceState(s)}
 override fun onPause(){pad.reset();pad.save();CookieManager.getInstance().flush();web.onPause();super.onPause()}
 override fun onResume(){super.onResume();if(::web.isInitialized)web.onResume();immersive()}
 override fun onWindowFocusChanged(f:Boolean){super.onWindowFocusChanged(f);if(::pad.isInitialized&&!f)pad.reset();if(f)immersive()}
 override fun onBackPressed(){if(keyboardPanel!=null){hideCustomKeyboard();return};if(menuDialog?.isShowing==true){menuDialog?.dismiss();return};if(custom!=null){web.webChromeClient?.onHideCustomView();return};settings()}
 override fun onDestroy(){chooser?.onReceiveValue(null);web.destroy();super.onDestroy()}
 data class Control(val name:String,val index:Int,var x:Float,var y:Float,var r:Float=.045f,var alpha:Float=.45f,var hidden:Boolean=false)
 inner class PadView:View(this@MainActivity){
  val elements=mutableListOf<Control>();val owners=mutableMapOf<Int,Control>();val axes=FloatArray(4);val buttons=FloatArray(17);val paint=Paint(3);var controlsEnabled=false;var edit=false;var shift=false;var selected:Control?=null;var sensitivity=1f;var deadzone=.12f
  init{defaults();load()}
  fun defaults(){elements.clear();elements.addAll(listOf(Control("L",-1,.15f,.72f,.095f),Control("R",-2,.74f,.72f,.095f),Control("A",0,.89f,.78f),Control("B",1,.95f,.67f),Control("X",2,.83f,.67f),Control("Y",3,.89f,.56f),Control("LB",4,.09f,.18f),Control("RB",5,.91f,.18f),Control("LT",6,.20f,.18f,.06f),Control("RT",7,.80f,.18f,.06f),Control("Select",8,.44f,.88f),Control("Start",9,.56f,.88f),Control("L3",10,.29f,.82f),Control("R3",11,.64f,.82f),Control("↑",12,.34f,.46f),Control("↓",13,.34f,.66f),Control("←",14,.28f,.56f),Control("→",15,.40f,.56f),Control("Xbox",16,.50f,.12f)));if(resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_PORTRAIT){elements.forEach{e->when(e.name){"L"->{e.x=.22f;e.y=.70f};"R"->{e.x=.68f;e.y=.70f};"A"->{e.x=.79f;e.y=.89f};"B"->{e.x=.91f;e.y=.83f};"X"->{e.x=.67f;e.y=.83f};"Y"->{e.x=.79f;e.y=.77f};"↑"->{e.x=.20f;e.y=.78f};"↓"->{e.x=.20f;e.y=.94f};"←"->{e.x=.08f;e.y=.86f};"→"->{e.x=.32f;e.y=.86f};"LB"->{e.x=.10f;e.y=.53f};"LT"->{e.x=.27f;e.y=.53f};"RT"->{e.x=.73f;e.y=.53f};"RB"->{e.x=.90f;e.y=.53f};"Select"->{e.x=.42f;e.y=.95f};"Start"->{e.x=.55f;e.y=.95f};"L3"->{e.x=.43f;e.y=.82f};"R3"->{e.x=.55f;e.y=.82f}}}};invalidate()}
  fun save(key:String="layout$layoutOrientation"){val arr=JSONArray();elements.forEach{arr.put(JSONObject().put("x",it.x).put("y",it.y).put("r",it.r).put("a",it.alpha).put("h",it.hidden))};prefs.edit().putString(key,arr.toString()).putFloat("sensitivity",sensitivity).putFloat("deadzone",deadzone).apply()}
  fun load(key:String="layout$layoutOrientation"){try{val a=JSONArray(prefs.getString(key,"[]"));elements.forEachIndexed{i,e->if(i<a.length()){val o=a.getJSONObject(i);e.x=o.getDouble("x").toFloat();e.y=o.getDouble("y").toFloat();e.r=o.getDouble("r").toFloat();e.alpha=o.getDouble("a").toFloat();e.hidden=o.getBoolean("h")}}}catch(_:Exception){};sensitivity=prefs.getFloat("sensitivity",1f);deadzone=prefs.getFloat("deadzone",.12f);reset()}
  fun send(){if(Uri.parse(web.url?:"").host!="daggerfalljs.dev")return;web.evaluateJavascript("window.__dfUpdate?.({axes:[${axes.joinToString()}],buttons:[${buttons.joinToString()}]})",null)}
  fun reset(){owners.clear();axes.fill(0f);buttons.fill(0f);if(shift){web.dispatchKeyEvent(KeyEvent(1,KeyEvent.KEYCODE_SHIFT_LEFT));shift=false};send();invalidate()}
  override fun onDraw(c:Canvas){if(!controlsEnabled&&!edit)return;val unit=min(width,height).toFloat();elements.forEach{e->if(e.hidden&&!edit)return@forEach;val x=e.x*width;val y=e.y*height;val r=e.r*unit;paint.color=if(edit&&selected===e)Color.YELLOW else Color.WHITE;paint.alpha=(e.alpha*255).toInt();paint.style=Paint.Style.STROKE;paint.strokeWidth=3f;c.drawCircle(x,y,r,paint);paint.style=Paint.Style.FILL;paint.textSize=16.dp.toFloat();paint.textAlign=Paint.Align.CENTER;c.drawText(e.name,x,y+paint.textSize/3,paint);if(e.index<0){val a=if(e.index==-1)0 else 2;c.drawCircle(x+axes[a]*r,y+axes[a+1]*r,r*.30f,paint)}else if(buttons[e.index]>0)c.drawCircle(x,y,r*.7f,paint)}}
  override fun onTouchEvent(ev:MotionEvent):Boolean {
   if(!controlsEnabled&&!edit)return false
   val id=ev.getPointerId(ev.actionIndex)
   if(ev.actionMasked==MotionEvent.ACTION_DOWN||ev.actionMasked==MotionEvent.ACTION_POINTER_DOWN){val x=ev.getX(ev.actionIndex);val y=ev.getY(ev.actionIndex);val e=elements.asReversed().firstOrNull{(!it.hidden||edit)&&hypot(x-it.x*width,y-it.y*height)<=it.r*min(width,height)};if(e==null&&ev.actionMasked==MotionEvent.ACTION_DOWN)return false;if(e!=null){owners[id]=e;if(edit)selected=e}}
   if(ev.actionMasked==MotionEvent.ACTION_CANCEL){reset();return true}
   if(ev.actionMasked==MotionEvent.ACTION_UP||ev.actionMasked==MotionEvent.ACTION_POINTER_UP){owners.remove(id);if(edit)save()}
   axes.fill(0f);buttons.fill(0f)
   for(i in 0 until ev.pointerCount){val pid=ev.getPointerId(i);val e=owners[pid]?:continue;if(edit){e.x=(ev.getX(i)/width).coerceIn(.02f,.98f);e.y=(ev.getY(i)/height).coerceIn(.02f,.98f);continue};if(e.index<0){val r=e.r*min(width,height);var x=(ev.getX(i)-e.x*width)/r;var y=(ev.getY(i)-e.y*height)/r;val len=hypot(x,y);val mag=if(len<=deadzone)0f else ((min(len,1f)-deadzone)/(1f-deadzone)*sensitivity).coerceIn(0f,1f);if(len>0){x=x/len*mag;y=y/len*mag};val a=if(e.index==-1)0 else 2;axes[a]=x;axes[a+1]=y}else {val v=if(e.index==6||e.index==7)((e.y*height+e.r*min(width,height)-ev.getY(i))/(2*e.r*min(width,height))).coerceIn(0f,1f)else 1f;buttons[e.index]=max(buttons[e.index],v)}}
   send();invalidate();return true
  }
 }
}
