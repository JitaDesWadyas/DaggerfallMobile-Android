const vm=require('vm'),fs=require('fs'),assert=require('assert');
const listeners={},state={username:'',password:''};let nodes=[],submitted=0;
class Element {constructor(){this.isConnected=true;this.disabled=false;this.readOnly=false}closest(){return null}getClientRects(){return this.isConnected?[{}]:[]}getAttribute(){return null}}
class Input extends Element {constructor(key,type,value){super();this.acctKey=key;this.type=type;this._value=value;this.selectionStart=value.length;this.selectionEnd=value.length;this.labels=[{textContent:key}];this.dataset={};this.oninput=()=>{state[this.acctKey.slice(6)]=this.value;repaint()}}get value(){return this._value}set value(v){this._value=v}dispatchEvent(e){if(e.type==='input'){state[this.acctKey.slice(6)]=this.value;repaint()}return true}focus(){doc.activeElement=this;win.__dfFocused=this}setSelectionRange(a,b){this.selectionStart=a;this.selectionEnd=b}closest(){return scope}}
class Textarea extends Input{}
const button=new Element();button.acctKey='act:submit';button.type='button';button.textContent='Sign in';button.click=()=>submitted++;
const scope={querySelector:()=>button,querySelectorAll:()=>[button]};
class EventTarget {addEventListener(type,fn){(this.listeners??={})[type]=fn}removeEventListener(type){delete this.listeners?.[type]}}
const doc=Object.assign(new EventTarget(),{querySelectorAll:()=>nodes,querySelector:()=>scope,body:{},activeElement:null});
function repaint(){nodes.forEach(e=>e.isConnected=false);nodes=[new Input('field:username','text',state.username),new Input('field:password','password',state.password)]}
const win=new EventTarget();const c={window:win,document:doc,EventTarget,Element,HTMLInputElement:Input,HTMLTextAreaElement:Textarea,Event:class{constructor(type){this.type=type}},getComputedStyle:()=>({visibility:'visible',display:'block'})};vm.createContext(c);repaint();vm.runInContext(fs.readFileSync(__dirname+'/../app/src/main/assets/login-fix.js','utf8'),c);
assert.equal(win.__dfLoginFix.fields().length,2);assert.equal(win.__dfLoginFix.fill(['test-user','aB!234'],true),true);assert.equal(state.username,'test-user');assert.equal(state.password,'aB!234');assert.equal(submitted,1);
assert(win.__dfLoginFix.focus());const input=doc.activeElement;input.setSelectionRange(0,4);assert(win.__dfLoginFix.type('new'));assert.equal(state.username,'new-user');win.__dfFocused=nodes[0];nodes[0].setSelectionRange(3,3);assert(win.__dfLoginFix.backspace());assert.equal(state.username,'ne-user');
let siteReceived=0;win.addEventListener('pointerdown',()=>siteReceived++);win.listeners.pointerdown({target:nodes[0]});assert.equal(siteReceived,0);win.listeners.pointerdown({target:button});assert.equal(siteReceived,1);assert.equal(typeof win.__dfLoginFix.focus,'function');
console.log('PASS: login fields survive rerender, native fill submits, custom insertion/replacement/backspace, global input-event shielding does not block input delivery.');
